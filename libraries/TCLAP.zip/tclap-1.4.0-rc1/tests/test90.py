#!/usr/bin/python

import simple_test

simple_test.test("test29", ["-h", ])
