#!/usr/bin/python

import simple_test

simple_test.test("test12", ["-v", "1 2 3", "-v", "4 5 6", "-v", "7 8 9", "-v", "-1 0.2 0.4", ])
