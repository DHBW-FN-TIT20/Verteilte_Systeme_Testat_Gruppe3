#!/usr/bin/python

import simple_test

simple_test.test("test12", [], expect_fail=True)
